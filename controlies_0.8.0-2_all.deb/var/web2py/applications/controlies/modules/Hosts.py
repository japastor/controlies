##############################################################################
# -*- coding: utf-8 -*-
# Project:     ControlIES
# Module:    Hosts.py
# Purpose:     Hosts class
# Language:    Python 2.5
# Date:        7-Feb-2011.
# Ver:        7-Feb-2011.
# Author:   Manuel Mora Gordillo
#           Francisco Mendez Palma
# Copyright:    2011 - Manuel Mora Gordillo <manuito @no-spam@ gmail.com>
#               2011 - Francisco Mendez Palma <fmendezpalma @no-spam@ gmail.com>
#
# ControlIES is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# ControlIES is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with ControlIES. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import ldap
import logging
import time
from math import floor
from operator import itemgetter
from Utils import ValidationUtils
import applications.controlies.modules.NetworkUtils as NetworkUtils
from netaddr import iter_iprange
from netaddr import IPAddress

class Hosts(object):

    def __init__(self):
        pass
    
    def __init__(self,ldap,name,ip,mac,wifimac,netgroup):
        self.ldap = ldap
        self.name = name
        self.original_name= ""
        self.ip = ip
        self.mac = mac
        self.wifimac = wifimac
        self.netgroup = netgroup
        
        config = self.ldap.search("cn=DHCP Config","cn=INTERNAL",["dhcpOption"])  
        self.domainname = config[0][0][1]['dhcpOption'][4].replace('"','').replace('domain-name ','')
            
    def validation(self,action):

        if self.netgroup == "none":
            return "netgroup"
    
        if self.name == "":
            return "name"

        if action == "add":
            if self.existsHostname(self.name):
                return "hostAlreadyExists"
                
        if action == "modify":
            if self.name != self.original_name and self.existsHostname(self.name):
                return "hostAlreadyExists"

        if self.ip == "":
            return "ip"

        if not ValidationUtils.validIP(self.ip):
            return "ip"

        partes = self.ip.split(".") #Solo admitimos ip que comienzan por 172 y por 10
        if partes[0] != "172" and partes[0] != "10":
            return "range_ip"

        rangos=self.getDHCPRanges()
        if self.checkIPRanges(rangos,self.ip) == "ERROR":
            return "dhcp_ip"

        if action == "add":            
            if self.existsIP():
                return "ipAlreadyExists"
        elif action == "modify":
            if not self.equalIP():
                if self.existsIP():
                    return "ipAlreadyExists"

        #Se debe definir almenos una MAC valida
        if self.mac == "" and self.wifimac== "" :
            return "mac"

        if self.mac != "" and not ValidationUtils.validMAC(self.mac):
                 return "mac"
  
        if self.wifimac != "" and  not ValidationUtils.validMAC(self.wifimac):
                   return "wifimac"

        if action == "add":  
            if self.existsMAC():
                return "macAlreadyExists"
            if self.existsMACWifi():
                return "macWifiAlreadyExists"
        elif action == "modify":            
            if not self.equalMAC(): #Si la MAC ha cambiado, verifica que la MAC nueva no existe ya.
                if self.existsMAC():
                    return "macAlreadyExists"
            if not self.equalMACWifi():
                                if self.existsMACWifi():
                                        return "macWifiAlreadyExists"
                    
        return "OK"

    def process(self,action,name_host):

        if action == "add":
            val = self.validation(action)
            
            if val != "OK":
                return val
            else:
                response = self.add()
                return response

        if action == "modify":
            self.original_name=name_host #Nombre original del host
            val = self.validation(action)
            
            if val != "OK":
                return val
            else:
                response = self.modify()
                return response
                
        if action == "delete":
            self.original_name=name_host #Nombre original del host
            response = self.delete()
            return response
        
        if action == "list":
            response = self.list();
            return response               

    def list(self,args):    
        # grid parameters
        limit = int(args['rows'])
        page = int(args['page'])
        start = limit * page - limit
        finish = start + limit;             

        # sort by field
        sortBy = args['sidx']

        # reverse Sort
        reverseSort = False
        if args['sord'] == "asc":
            reverseSort = True        
                                
        allhosts = self.getAllHosts()

        allmacs = {}
        allwifimacs = {}
        search = self.ldap.search("cn=INTERNAL,cn=DHCP Config","cn=*",["cn","dhcpHWAddress"])
        for s in search:
             try:
                 name = s[0][1]['cn'][0]
                 mac = s[0][1]['dhcpHWAddress'][0].replace("ethernet ","")
                 if s[0][0].find("cn=wifi-group") == -1 :
                         allmacs[name]=mac
                 else:
                         allwifimacs[name]=mac
             except:
                 pass

        allnetgroups = {}
        search = self.ldap.search("ou=Netgroup","cn=*",["cn","nisNetgroupTriple"])
        for s in search:
             try:
                 netgroup = s[0][1]['cn'][0]
                 triplets =  s[0][1]['nisNetgroupTriple']
                 for hosts in triplets:
                      host=hosts.replace("(","").replace(",-,-)","")
                      allnetgroups[host]=netgroup
             except:
                 pass

        rows = []

        try:
            host_search = args["cn"] or ""
        except:
            host_search = ""
            
        try:
            ip_search = args["ipHostNumber"] or ""
        except:
            ip_search = ""

        try:
            mac_search = args["macAddress"] or ""
        except:
            mac_search = ""

        try:
            mac_wifi_search = args["macWifiAddress"] or ""
        except:
            mac_wifi_search = ""

        try:
            netgroup_search = args["netgroup"] or ""
        except:
            netgroup_search = ""
           
        for v in allhosts:
            try:
                host = v[0]
            except:
                host = ""

            try:
                ip = v[1]
            except:
                ip = ""

            try:
                mac = allmacs[host]
            except:
                mac = ""

            try:
                wifimac = allwifimacs[host]
            except:
                wifimac = ""

            try:
                netgroup = allnetgroups[host]
            except:
                netgroup = ""

            if ((ip_search != "" and ip.find(ip_search)>=0) or (ip_search=="")) and ((mac_search != "" and mac.find(mac_search)>=0) or (mac_search=="")) and ((host_search != "" and host.find(host_search)>=0) or (host_search=="")) and ((mac_wifi_search != "" and wifimac.find(mac_wifi_search)>=0) or (mac_wifi_search=="")) and ( (netgroup_search=="(null)" and netgroup=="") or (netgroup_search != "" and netgroup==netgroup_search) or (netgroup_search=="")) :
                row = {
                    "id":host, 
                    "cell":[host, ip, mac, wifimac, netgroup],
                    "cn":host,
                    "ipHostNumber":ip,
                    "macAddress":mac,
                                        "macWifiAddress": wifimac,
                                        "netgroup": netgroup
                }
                rows.append(row)

        if len(rows) > 0:
            totalPages = floor( len(rows) / int(limit) )
            module = len(rows) % int(limit)

            if module > 0:
                totalPages = totalPages+1
        else:
            totalPages = 0

        if page > totalPages:
            page = totalPages

        result = sorted(rows, key=itemgetter(sortBy), reverse=reverseSort)
        return { "page":page, "total":totalPages, "records":len(rows), "rows":result[start:finish]  }   
        
    def add(self):

        # Hosts->domain
        attr = [
        ('objectclass', ['dNSDomain2','domainRelatedObject']),
        ('associatedDomain', [self.name+'.'+self.domainname]),
        ('dc', [self.name]), 
        ('aRecord', [self.ip])
        ]
        self.ldap.add("dc="+self.name+",dc="+self.domainname+",ou=Hosts", attr)

        # Hosts->arpa->in-addr->...
        self.add_ip_with_subtree()

    # DHCP Config
        if self.mac != "" :
             attr = [
             ('objectclass', ['top','dhcpHost']),
             ('dhcpStatements', ['fixed-address '+self.name]),
             ('cn', [self.name]), 
             ('dhcpHWAddress', ['ethernet '+self.mac])
             ]
             self.ldap.add("cn="+self.name+",cn=group1,cn=INTERNAL,cn=DHCP Config", attr)

        if self.wifimac != "" :
             attr = [
             ('objectclass', ['top','dhcpHost']),
             ('dhcpStatements', ['fixed-address '+self.name]),
             ('cn', [self.name]),
             ('dhcpHWAddress', ['ethernet '+self.wifimac])
             ]
             self.ldap.add("cn="+self.name+",cn=wifi-group,cn=INTERNAL,cn=DHCP Config", attr)

        # Netgroup            
        triplets = self.getTriplets(self.netgroup)
        triplets.append('('+self.name+',-,-)')
        triplets.sort()
        attr = [(ldap.MOD_REPLACE, 'nisNetgroupTriple', triplets )]
        self.ldap.modify("cn="+self.netgroup+",ou=Netgroup", attr)
            
        return "OK"
        
    def modify(self):
        #Los valores que entran en name, ip, mac, wifimac y netgroup son los del formulario
        #Para saber los valores en ldap hay que usar getIP, getMAC, getNegroup y getWifiMAC y comparar

        #Antes de empezar a modificar recuperamos la IP, MAC y Netgroup de ldap
        myIP=self.getIP()
        mac=self.getMAC()
        wifimac=self.getWifiMAC()
        netgroup=self.getNetGroup()

        # Hosts->domain
        if self.original_name == self.name :
            attr = [(ldap.MOD_REPLACE, 'aRecord', [self.ip] )]
            self.ldap.modify("dc="+self.name+",dc="+self.domainname+",ou=Hosts", attr)
        else:
            attr = [
                   (ldap.MOD_REPLACE, 'associatedDomain', [self.name + "." +self.domainname] ),
                   (ldap.MOD_REPLACE, 'aRecord', [self.ip] )
            ]
            self.ldap.modify("dc="+self.original_name+",dc="+self.domainname+",ou=Hosts", attr)
            self.ldap.rename("dc="+self.domainname+",ou=Hosts", "dc="+self.original_name, "dc="+self.name)

        if self.ip!=myIP or self.original_name != self.name : #Si la IP o el nombre del equipo ha cambiado->se borra el nodo y se inserta de nuevo.
            if myIP != "":

                ip = myIP.split(".")
                self.ldap.delete("dc="+ip[3]+",dc="+ip[2]+",dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=Hosts")
                self.add_ip_with_subtree()

        # DHCP Config
        # Cambio MAC: hay mucha casuistica en función de si habia o no antes MAC y si está se ha modificado/borrado o no
        if mac == "" : 
            if self.mac != "" :    # Hemos definido MAC y antes no habia, hay que añadirla
                attr = [
                ('objectclass', ['top','dhcpHost']),
                ('dhcpStatements', ['fixed-address '+self.name]),
                ('cn', [self.name]),
                ('dhcpHWAddress', ['ethernet '+self.mac])
                ]
                self.ldap.add("cn="+self.name+",cn=group1,cn=INTERNAL,cn=DHCP Config", attr)
        else: #Tenia MAC definida en ldap
            if self.mac == "" :       #La nueva MAC esta vacia, hay que borrarla
                self.ldap.delete("cn="+self.original_name+",cn=group1,cn=INTERNAL,cn=DHCP Config")
            elif self.mac != mac or self.original_name != self.name :      #Ha cambiado la MAC o el nombre, hay que modificar
                #attr = [(ldap.MOD_REPLACE, 'dhcpHWAddress', ['ethernet '+self.mac] )]
                attr = [
                       (ldap.MOD_REPLACE, 'dhcpHWAddress', ['ethernet '+self.mac]),
                       (ldap.MOD_REPLACE, 'dhcpStatements', ['fixed-address '+self.name]),
                ]
                self.ldap.modify("cn="+self.original_name+",cn=group1,cn=INTERNAL,cn=DHCP Config", attr)
                if self.original_name != self.name:
                     self.ldap.rename("cn=group1,cn=INTERNAL,cn=DHCP Config","cn="+self.original_name, "cn="+self.name)

        if wifimac == "" :                        
            if self.wifimac != "" :    # Hemos definido MAC y antes no habia, hay que añadirla
                attr = [
                ('objectclass', ['top','dhcpHost']),
                ('dhcpStatements', ['fixed-address '+self.name]),
                ('cn', [self.name]),
                ('dhcpHWAddress', ['ethernet '+self.wifimac])
                ]
                self.ldap.add("cn="+self.name+",cn=wifi-group,cn=INTERNAL,cn=DHCP Config", attr)
        else: #Tenia MAC definida en ldap
            if self.wifimac == "" :       #La nueva MAC esta vacia, hay que borrarla
                self.ldap.delete("cn="+self.original_name+",cn=wifi-group,cn=INTERNAL,cn=DHCP Config")
            elif self.wifimac != wifimac or self.original_name != self.name :     #Ha cambiado la MAC o el nombre, hay que modificar
                attr = [
                       (ldap.MOD_REPLACE, 'dhcpHWAddress', ['ethernet '+self.wifimac]),
                       (ldap.MOD_REPLACE, 'dhcpStatements', ['fixed-address '+self.name]),
                ]
                self.ldap.modify("cn="+self.original_name+",cn=wifi-group,cn=INTERNAL,cn=DHCP Config", attr)
                if self.original_name != self.name :
                     self.ldap.rename("cn=wifi-group,cn=INTERNAL,cn=DHCP Config","cn="+self.original_name, "cn="+self.name)

        if netgroup != self.netgroup or self.original_name != self.name : # Si el netgroup o el nombre del equipo ha cambiado
            #Borramos del netrgroup viejo
            if netgroup != "":
                  triplets = self.getTriplets(netgroup)
                  triplets.remove('('+self.original_name+',-,-)')
                  triplets.sort()
                  attr = [(ldap.MOD_REPLACE, 'nisNetgroupTriple', triplets )]
                  self.ldap.modify("cn="+netgroup+",ou=Netgroup", attr) # Borramos del netgroup viejo

            #Insertamos en el netgroup nuevo
            triplets = self.getTriplets(self.netgroup)
            triplets.append('('+self.name+',-,-)')
            triplets.sort()
            attr = [(ldap.MOD_REPLACE, 'nisNetgroupTriple', triplets )]
            self.ldap.modify("cn="+self.netgroup+",ou=Netgroup", attr)

        return "OK"

    def add_ip_with_subtree(self):
   
        ip = self.ip.split(".")
       
        result = self.ldap.search ("dc="+ip[0]+",dc=in-addr,dc=arpa,ou=hosts", "dc=*", ["dc"])
        if result is None:
            attr = [
            ('objectclass', ['top','dNSDomain2','domainRelatedObject']),
            ('associatedDomain', [ip[0]+".in-addr.arpa"]),
            ('dc', [ip[0]])
            ]
            self.ldap.add("dc="+ip[0]+",dc=in-addr,dc=arpa,ou=Hosts", attr)

        result = self.ldap.search ("dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=hosts", "dc=*", ["dc"])
        if result is None:
            attr = [
            ('objectclass', ['top','dNSDomain2','domainRelatedObject']),
            ('associatedDomain', [ip[1]+"."+ip[0]+".in-addr.arpa"]),
            ('dc', [ip[1]]),
            ('sOARecord', ['domain.'+self.domainname+' hostmaster@'+self.domainname +' 1 1800 3600 86400 7200']),
            ('nSRecord', ['domain.'+self.domainname])
            ]
            self.ldap.add("dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=Hosts", attr)

        result = self.ldap.search ("dc="+ip[2]+",dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=hosts", "dc=*", ["dc"])
        if result is None:
           attr = [
           ('objectclass', ['top','dNSDomain2','domainRelatedObject']),
           ('associatedDomain', [ip[2]+"."+ip[1]+"."+ip[0]+".in-addr.arpa"]),
           ('dc', [ip[2]])
           ]
           self.ldap.add("dc="+ip[2]+",dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=Hosts", attr)

        attr = [
        ('objectclass', ['top','dNSDomain2','domainRelatedObject']),
        ('associatedDomain', [ip[3]+"."+ip[2]+"."+ip[1]+"."+ip[0]+".in-addr.arpa"]),
        ('dc', [ip[3]]),
        ('pTRRecord', [self.name+"."+self.domainname])
        ]
        self.ldap.add("dc="+ip[3]+",dc="+ip[2]+",dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=Hosts", attr)

        return "OK"

    def delete(self):
        self.ldap.delete("cn="+self.name+",ou=Hosts")
        self.ldap.delete("cn="+self.name+",cn=group1,cn=INTERNAL,cn=DHCP Config")
        self.ldap.delete("cn="+self.name+",cn=wifi-group,cn=INTERNAL,cn=DHCP Config")

        #Hosts->arpa
        myIP = self.getIP()
        if myIP != "":
            ip = myIP.split(".")
            self.ldap.delete("dc="+ip[3]+",dc="+ip[2]+",dc="+ip[1]+",dc="+ip[0]+",dc=in-addr,dc=arpa,ou=Hosts")

        self.ldap.delete("dc="+self.name+",dc="+self.domainname+",ou=Hosts")

        # Netgroup            
        self.netgroup = self.getNetGroup()

        triplets = self.getTriplets(self.netgroup)
        triplets.remove('('+self.name+',-,-)')
        triplets.sort()
            
        attr = [(ldap.MOD_REPLACE, 'nisNetgroupTriple', triplets )]
        self.ldap.modify("cn="+self.netgroup+",ou=Netgroup", attr)

        return "OK"     

    def addTriplet(self):
        # Netgroup            
        triplets = self.getTriplets(self.netgroup)
        triplets.append('('+self.name+',-,-)')
        triplets.sort()
        attr = [(ldap.MOD_REPLACE, 'nisNetgroupTriple', triplets )]
        self.ldap.modify("cn="+self.netgroup+",ou=Netgroup", attr)

    def deleteTriplet(self):
        # Netgroup            
        triplets = self.getTriplets(self.netgroup)
        triplets.remove('('+self.name+',-,-)')
        triplets.sort()   
        attr = [(ldap.MOD_REPLACE, 'nisNetgroupTriple', triplets )]
        self.ldap.modify("cn="+self.netgroup+",ou=Netgroup", attr)

    def wakeup(self,broadcast):
        NetworkUtils.startup(self.getMAC(),broadcast)
    
    def existsHostname(self, nombre):
        if nombre  in self.getListTriplets():
            return True
        
        return False
        
    def existsMAC(self):
        search = self.ldap.search("cn=INTERNAL,cn=DHCP Config","cn=*",["cn","dhcpHWAddress"])
        
        for s in search:
            try:
                mac_nodo =  s[0][1]["dhcpHWAddress"][0].replace("ethernet ","")
                if mac_nodo == self.mac : 
                    return True
            except:
                pass

        return False


    def existsMACWifi(self):
        search = self.ldap.search("cn=INTERNAL,cn=DHCP Config","cn=*",["cn","dhcpHWAddress"])

        for s in search:
                        try:
                                mac_nodo =  s[0][1]["dhcpHWAddress"][0].replace("ethernet ","")
                                if mac_nodo == self.wifimac :
                                        return True
                        except:
                                pass

        return False

    def existsIP (self):
        # Cojo las ips de la rama hosts -> arpa -> in-addr
        result = self.ldap.search ("dc=172,dc=in-addr,dc=arpa,ou=hosts", "dc=*",["associatedDomain"])
        myIP = self.ip.split (".")

        for i in range (0, len (result)): #Bug de hace 12 años arreglado. El bucle original era hasta len(result) - 1
            ip_ldap=result [i][0][1]['associatedDomain'][0].replace (".in-addr.arpa","")
            reverseIP = ip_ldap.split(".")
            reverseIP.reverse() 
            if myIP == reverseIP:
                return True
        
        return False

    def equalMAC(self):
        if self.getMAC() == self.mac:
            return True
        
        return False

    def equalMACWifi(self): 
        if self.getWifiMAC() == self.wifimac:
            return True

        return False


    def equalIP(self):                
        if self.getIP() == self.ip:
            return True
        
        return False
        

    def getName (self):
        return self.mac   

        
    def getInternalGroups (self):
        
        groups = []
        search = self.ldap.search("cn=INTERNAL,cn=DHCP Config","cn=group*",["cn"])
        
        for g in search:
            groups.append (g[0][1]["cn"][0])
            
        return { "groups":groups }      

    def getTriplets(self,netgroup):
        triplets = self.ldap.search("ou=Netgroup","cn="+netgroup+"",["nisNetgroupTriple"])
        try:
            triplets = triplets [0][0][1]["nisNetgroupTriple"]
        except:
            triplets = []

        return triplets

    def getListTriplets(self):
        hostnames = []      
        triplets = self.ldap.search("ou=Netgroup","cn="+self.netgroup+"",["nisNetgroupTriple"]) 

        try:
            triplets = triplets [0][0][1]["nisNetgroupTriple"]
        
            for t in triplets:
                hostnames.append(t.replace("(","").replace(",-,-)",""))

        except:
            pass

        return hostnames

    def getAllHosts(self):

          hostdata = []
          nodos =  self.ldap.search("dc="+self.domainname+",ou=hosts","(arecord=*)",["dc","arecord"])

          try:
             for h in nodos:
                     nombre=h[0][1]['dc'][0]
                     ip=h[0][1]['aRecord'][0]
                     hostdata.append([nombre,ip])
          except:
             pass

          return hostdata

    def getHostData(self):

        self.original_name=self.name
        dataHost = {
            "cn":self.name,
            "mac":self.getMAC(),
            "wifimac":self.getWifiMAC(),
            "ip":self.getIP(),
            "netgroup": self.getNetGroup()
        }
        return dataHost             

    def getIP(self):
        search = self.ldap.search("dc="+self.domainname+",ou=hosts","dc="+self.original_name,["dc","aRecord"])
        ip=""
        try:
            ip = search[0][0][1]["aRecord"][0]
        except:
            pass
        return ip

    def getMAC(self):
        search = self.ldap.search("cn=group1,cn=INTERNAL,cn=DHCP Config","cn="+self.original_name,["cn","dhcpHWAddress"])
        mac=""
        try:
            mac = search[0][0][1]["dhcpHWAddress"][0].replace("ethernet ","")        
        except:
            pass
        return mac

    def getWifiMAC(self):
        search = self.ldap.search("cn=wifi-group,cn=INTERNAL,cn=DHCP Config","cn="+self.original_name,["cn","dhcpHWAddress"])
        wifimac=""
        try:
            wifimac = search[0][0][1]["dhcpHWAddress"][0].replace("ethernet ","")
        except:
            pass
        return wifimac

    def getNetGroup(self):

        netgroup_host = ""
        search = self.ldap.search("ou=Netgroup","cn=*",["cn","nisNetgroupTriple"])
        for s in search:
             try:
                 netgroup = s[0][1]['cn'][0]
                 triplets =  s[0][1]['nisNetgroupTriple']
                 for hosts in triplets:   
                       host=hosts.replace("(","").replace(",-,-)","")                  
                       if host == self.original_name:
                            netgroup_host=netgroup
                            break
                 else:              #Si el bucle interno acaba bien, se itera el bucle externo una vez más. Este "else:" en un for es algo de python
                       continue
                 break  #Si el bucle interno acaba con break, se lanza un break en el externo.
             except:
                 pass
        return netgroup_host

    def getLTSPStatus (self):
        from Utils.avahiClient import avahiClient
        import threading
        
        a = avahiClient()  
        a.start() 
        time.sleep(1000)    
        a.cancel()      
        names = a.getList()
        print names
        
        """a = avahiClient()
        time.sleep(1000)        
        names = a.getList()
        print names
        a.kill()"""
        return names

    def getNetGroups (self):
        netgroups = []
        search = self.ldap.search("ou=Netgroup","cn=*",["cn","nisNetgroupTriple"])
        for s in search:
             try:
                 netgroup = s[0][1]['cn'][0]
                 #triplets =  s[0][1]['nisNetgroupTriple']
                 #for hosts in triplets:     host=hosts.replace("(","").replace(",-,-)","")
                 netgroups.append(netgroup)
             except:
                 pass
        return netgroups

    def getNetGroupsNonEmpty (self):
        netgroups = []
        search = self.ldap.search("ou=Netgroup","cn=*",["cn","nisNetgroupTriple"])
        for s in search:
             try:
                netgroup = s[0][1]['cn'][0]
                #Contamos el numero de miembros.
                try:
                    list = [x for x in s[0][1]["nisNetgroupTriple"] if x]
                    hostsNumber = len(list)                    
                except:
                    hostsNumber = 0
                 
                if hostsNumber>0: 
                    netgroups.append(netgroup)                    
                
             except:
                 pass
        netgroups.sort(reverse=True)
        return netgroups

    def getNetGroupsWithMembers (self):
        #Devuelve una lista parejas de grupos y número de miembros del mismo
        netgroups = []
        search = self.ldap.search("ou=Netgroup","cn=*",["cn","nisNetgroupTriple"])
        for s in search:
             try:
                netgroup = s[0][1]['cn'][0]
                #Contamos el numero de miembros.
                try:
                    list = [x for x in s[0][1]["nisNetgroupTriple"] if x]
                    hostsNumber = len(list)                    
                except:
                    hostsNumber = 0
                 
                
                netgroups.append({"name": netgroup, "membersNo": hostsNumber})                    
                
             except:
                 pass
        return netgroups


    def createStructure(self):
        attr = [
        ('cn', [self.netgroup]),
        ('objectClass', ['top','nisNetgroup'])
        ]
        self.ldap.add("cn="+self.netgroup+",ou=Netgroup", attr)

    def getDHCPRanges(self):
        ranges = []
        search = self.ldap.search("cn=DHCP Config","objectClass=dhcpSubnet",["cn","dhcpRange"])
        for s in search:
             try:
                 range = s[0][1]['dhcpRange'][0]
                 ranges.append(range)
             except:
                 pass
        return ranges

    def checkIPRanges(self, ranges, ip):

        retorno="OK"  
        if len(ranges) > 0:
             for rango in ranges:
                 IPs = rango.split(" ")
                 lista_ips = list(iter_iprange(IPs[0],IPs[1], step=1))
                 for value in lista_ips:
                     if ip == str(value): 
                        retorno="ERROR"
                        break
        return retorno

def log(mensaje):
    logfile = open("/tmp/controlies.txt", "a")
    logfile.write(mensaje+"\n")
    logfile.close()
