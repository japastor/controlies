##############################################################################
# -*- coding: utf-8 -*-
# Project:     ControlIES
# Module:    Thinclients.py
# Purpose:     Thinclients class
# Language:    Python 2.5
# Date:        4-Oct-2011.
# Ver:        4-Oct-2011.
# Author:   Manuel Mora Gordillo
# Copyright:    2011 - Manuel Mora Gordillo <manuito @no-spam@ gmail.com>
#
# ControlIES is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# ControlIES is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with ControlIES. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import ldap
import logging
import time
from math import floor
from operator import itemgetter
from Utils import ValidationUtils
from applications.controlies.modules.Users import Users

class Thinclients(object):

    def __init__(self):
        pass
    
    def __init__(self,ldap,name="",mac="",macWlan="",serial="",username="",ip=""):
        self.ldap = ldap
        self.name = name
        self.original_name = ""
        self.mac = mac
        self.macWlan = macWlan
        self.serial = serial
        self.username = username
        self.ip = ip

    def validation(self,action):
        
        if self.name == "" :
            return "name"

        if not ValidationUtils.validHostName(self.name):
            return "bad_name"
            
        if action == "add":
            if self.existsHostname():
                return "hostAlreadyExists"

        if action == "modify":
            if self.name != self.original_name and self.existsHostname():
                return "hostAlreadyExists"

        if self.mac == "" and self.macWlan == "" :
            return "mac"
        
        if self.mac != "" and  not ValidationUtils.validMAC(self.mac):
            return "mac"      
            
        if self.macWlan != "" and not ValidationUtils.validMAC(self.macWlan):
            return "macWlan"                                          

        if self.ip != "" and not ValidationUtils.validIP(self.ip):
            return "ip"

        if self.mac == self.macWlan:
            return "macWlanAlreadyExists"
        
        if self.username != "":
            u = Users(self.ldap,"","","","",self.username,"","","","")
            exists = u.existsUsername()
            if not exists:
                return "userNotExists"   
                
        if action == "add":
            if self.existsMAC(self.mac):
                return "macAlreadyExists"
            if self.existsMAC(self.macWlan):
                return "macWlanAlreadyExists"
        elif action == "modify": #Si es una modificación, solo comprobar si se ha cambiado la mac.
            old_mac=self.getldapMAC(self.original_name)
            old_wifimac=self.getldapWifiMAC(self.original_name)
            if self.mac != old_mac: 
                if self.existsMAC(self.mac):
                     return "macAlreadyExists"
            if self.macWlan != old_wifimac:
                if self.existsMAC(self.macWlan):
                     return "macWlanAlreadyExists"

        return "OK"

    def process(self,action,name_thinclient):

        if action == "add":
            self.original_name=name_thinclient
            val = self.validation(action)
            
            if val != "OK":
                return val
            else:
                response = self.add()
                return response

        if action == "modify":
            self.original_name=name_thinclient #Nombre original del host
            val = self.validation(action)
            
            if val != "OK":
                return val
            else:
                response = self.modify()
                return response
                
        if action == "delete":
            self.original_name=name_thinclient #Nombre original del host
            response = self.delete()
            return response
        
        if action == "list":
            response = self.list();
            return response               
            
    def list(self,args):
                
        # grid parameters
        limit = int(args['rows'])
        page = int(args['page'])
        start = limit * page - limit
        finish = start + limit;             

        # sort by field
        sortBy = args['sidx']
        #if sortBy == "uid":
            #sortBy = "id"

        # reverse Sort
        reverseSort = False
        if args['sord'] == "asc":
            reverseSort = True
        
        search = self.ldap.search("cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn","dhcpHWAddress","uniqueIdentifier","dhcpComments","dhcpStatements"])
        rows = []

        try:
            host_search = args["cn"] or ""
        except:
            host_search = ""
            
        try:
            mac_search = args["mac"] or ""
        except:
            mac_search = ""

        try:
            macWlan_search = args["macWlan"] or ""
        except:
            macWlan_search = ""

        try:
            user_search = args["username"] or ""
        except:
            user_search = ""

        try:
            serial_search = args["serial"] or ""
        except:
            serial_search = ""

        try:
            ip_search = args["ip"] or ""
        except:
            ip_search = ""

        macsWlan={}
        macsWired={}
        for i in search[6:len(search)]:
            if len(i[0][0].split(","))>6 and "wifi" in i[0][0].split(",")[1]:
                try:
                    macsWlan[i[0][1]["cn"][0]] = i[0][1]["dhcpHWAddress"][0].replace("ethernet","").strip()
                except:
                    pass
            elif len(i[0][0].split(","))>6 and not "wifi" in i[0][0].split(",")[1]:
                try:
                    macsWired[i[0][1]["cn"][0]] = i[0][1]["dhcpHWAddress"][0].replace("ethernet","").strip()
                except:
                    pass


        for i in search[6:len(search)]:

            if len(i[0][0].split(","))>6 : #Si el cn tiene mas de 7 niveles de profundidad
           
                host = i[0][1]["cn"][0]

                try:
                     mac =  macsWired[host]  
                except:
                     mac = ""
                try:
                     macWlan = macsWlan[host]
                except:
                     macWlan = ""

                if mac != "" and macWlan != "":  #Si tenemos ambas MAC el equipo está duplicado en la rama DHCP, pero debe saler una sola vez en el grid
                        if "wifi" in i[0][0].split(",")[1] : continue
                      
                try:
                    username = i[0][1]["uniqueIdentifier"][0].replace("user-name","").strip()
                except:
                    username = ""

                try:
                    serial = i[0][1]["dhcpComments"][0].replace("serial-number","").strip()
                except:
                    serial = ""

                try:
                    matching = [s for s in i[0][1]["dhcpStatements"] if "fixed-address" in s]
                    ip=""
                    if matching: ip=matching[0].replace("fixed-address ","")
                except:
                    ip = ""

                if ((host_search != "" and host.find(host_search)>=0) or (host_search=="")) and ((mac_search != "" and mac.find(mac_search)>=0) or (mac_search=="")) and ((macWlan_search != "" and macWlan.find(macWlan_search)>=0) or (macWlan_search=="")) and ((ip_search != "" and ip.find(ip_search)>=0) or (ip_search=="")) and ((serial_search != "" and serial.find(serial_search)>=0) or (serial_search=="")) and ((user_search != "" and username.find(user_search)>=0) or (user_search=="")):# and ((ip_search != "" and ip.find(ip_search)>=0) or (ip_search=="")):
                    nodeinfo=i[0][0].replace ("cn=","").split(",")
                    row = {
                        "id":host, 
                        "cell":[host, mac, macWlan, ip, username, serial],
                        "cn":host,
                        "mac":mac,
                        "macWlan":macWlan,
                        "ip":ip,
                        "username":username,
                        "serial":serial,
                    }             
                    rows.append(row)

        if len(rows) > 0:
            totalPages = floor( len(rows) / int(limit) )
            module = len(rows) % int(limit)

            if module > 0:
                totalPages = totalPages+1
        else:
            totalPages = 0
            
        if page > totalPages:
            page = totalPages
            
        result = sorted(rows, key=itemgetter(sortBy), reverse=reverseSort)
        return { "page":page, "total":totalPages, "records":len(rows), "rows":result[start:finish] }                    
    
    
    def getThinclients(self):
               
        search = self.ldap.search("cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn","dhcpHWAddress","uniqueIdentifier","dhcpComments","dhcpStatements"])
        rows = []
        
        macsWlan={}
        macsWired={}
        for i in search[6:len(search)]:
            if len(i[0][0].split(","))>6 and "wifi" in i[0][0].split(",")[1]:
                try:
                    macsWlan[i[0][1]["cn"][0]] = i[0][1]["dhcpHWAddress"][0].replace("ethernet","").strip()
                except:
                    pass
            elif len(i[0][0].split(","))>6 and not "wifi" in i[0][0].split(",")[1]:
                try:
                    macsWired[i[0][1]["cn"][0]] = i[0][1]["dhcpHWAddress"][0].replace("ethernet","").strip()
                except:
                    pass


        for i in search[6:len(search)]:

            if len(i[0][0].split(","))>6 : #Si el cn tiene mas de 7 niveles de profundidad
           
                host = i[0][1]["cn"][0]

                try:
                     mac =  macsWired[host]  
                except:
                     mac = ""
                try:
                     macWlan = macsWlan[host]
                except:
                     macWlan = ""

                if mac != "" and macWlan != "":  #Si tenemos ambas MAC el equipo está duplicado en la rama DHCP, pero debe saler una sola vez la lista
                        if "wifi" in i[0][0].split(",")[1] : continue
                      
                try:
                    username = i[0][1]["uniqueIdentifier"][0].replace("user-name","").strip()
                except:
                    username = ""

                try:
                    serial = i[0][1]["dhcpComments"][0].replace("serial-number","").strip()
                except:
                    serial = ""

                try:
                    matching = [s for s in i[0][1]["dhcpStatements"] if "fixed-address" in s]
                    ip=""
                    if matching: ip=matching[0].replace("fixed-address ","")
                except:
                    ip = ""

                
                nodeinfo=i[0][0].replace ("cn=","").split(",")
                row = {
                    "id":host, 
                    "cell":[host, mac, macWlan, ip, username, serial],
                    "cn":host,
                    "mac":mac,
                    "macWlan":macWlan,
                    "ip":ip,
                    "username":username,
                    "serial":serial,
                }             
                rows.append(row)

        return rows
          

    def add(self):
        
        if self.mac !="" :   
            self.addNode()

        if self.macWlan != "":   
            self.addWifiNode()
            
        return "OK"
        
    def addNode(self):
        classroom = self.getClassroom()
        groups = self.getThinclientGroups()
        
        if not classroom in groups['groups']: self.newGroup(classroom)
        attr = [
        ('objectclass', ['top','dhcpHost','lisPerson']),
        ('cn', [self.name] ),
        ('dhcpStatements', ['filename "/var/lib/tftpboot/ltsp/i386/pxelinux.0"','fixed-address ' + self.ip] ), 
        ('dhcpComments', ['serial-number ' + self.serial] ), 
        ('dhcpHWAddress', ['ethernet ' + self.mac] ),
        ('uniqueIdentifier', ['user-name ' + self.username]),
        ]
        self.ldap.add("cn="+self.name +",cn="+classroom+",cn=THINCLIENTS,cn=DHCP Config", attr)
            
        
    def addWifiNode(self):
        classroom = self.getClassroom()
        groups = self.getThinclientGroups()

        if not classroom+"-wifi" in groups['groups']: self.newGroup(classroom+"-wifi")
        attr = [
        ('objectclass', ['top','dhcpHost','lisPerson']),
        ('cn', [self.name] ),
        ('dhcpStatements', ['fixed-address ' + self.ip] ), 
        ('dhcpComments', ['serial-number ' + self.serial] ), 
        ('dhcpHWAddress', ['ethernet ' + self.macWlan] ),
        ('uniqueIdentifier', ['user-name ' + self.username]),
        ]
        self.ldap.add("cn="+self.name +",cn="+classroom+"-wifi"+",cn=THINCLIENTS,cn=DHCP Config", attr)

    def modify(self):
        
        if self.name == self.original_name: # Si no se ha cambiado el nombre
            classroom = self.getClassroom()
            groups = self.getThinclientGroups()

            if self.mac != "":
                if not classroom in groups['groups']: self.newGroup(classroom)
                #Si no existe, se añade       
                if self.existsNode():
                    attr = [
                    (ldap.MOD_REPLACE, 'dhcpHWAddress', ['ethernet ' + self.mac] ),
                    (ldap.MOD_REPLACE, 'dhcpStatements', ['filename "/var/lib/tftpboot/ltsp/i386/pxelinux.0"', 'fixed-address ' + self.ip]),
                    (ldap.MOD_REPLACE, 'dhcpComments', ['serial-number ' + self.serial] ),      
                    (ldap.MOD_REPLACE, 'uniqueIdentifier', ['user-name ' + self.username] )
                    ]
                    self.ldap.modify("cn="+self.name+",cn="+classroom+",cn=THINCLIENTS,cn=DHCP Config", attr)
                else:
                    self.addNode()
            else: 
                self.ldap.delete('cn='+ self.name +',cn='+classroom+',cn=THINCLIENTS,cn=DHCP Config')
                   
            if self.macWlan != "" :
                if not classroom+"-wifi" in groups['groups']: self.newGroup(classroom+"-wifi") 
                if self.existsWifiNode():
                    attr = [
                    (ldap.MOD_REPLACE, 'dhcpHWAddress', ['ethernet ' + self.macWlan] ),
                    (ldap.MOD_REPLACE, 'dhcpStatements', ['fixed-address ' + self.ip]),
                    (ldap.MOD_REPLACE, 'dhcpComments', ['serial-number ' + self.serial] ),      
                    (ldap.MOD_REPLACE, 'uniqueIdentifier', ['user-name ' + self.username])
                    ]
                    self.ldap.modify("cn="+self.name+",cn="+classroom+"-wifi,cn=THINCLIENTS,cn=DHCP Config", attr)   
                else:
                   self.addWifiNode()
            else: 
                self.ldap.delete('cn='+ self.name +',cn='+classroom+'-wifi,cn=THINCLIENTS,cn=DHCP Config')
        else: #Si ha cambiado el nombre, borramos y añadimos de nuevo, ya que puede haber cambiado de subrama dhcp y con un renombrado no es suficiente
            try:
                group = self.original_name.split("-")[0]
                self.ldap.delete('cn='+ self.original_name +',cn='+group+',cn=THINCLIENTS,cn=DHCP Config')
                self.ldap.delete('cn='+ self.original_name +',cn='+group+'-wifi,cn=THINCLIENTS,cn=DHCP Config')                
                self.add()
                self.deleteEmptyGroup(group) #Si la rama ha quedado vacia, se borra.
            except:
                pass
        
        return "OK"

    def modifyUser(self):
        grupo=self.getGroup()
        attr = [(ldap.MOD_REPLACE, 'uniqueIdentifier', ['user-name ' + self.username])]
        self.ldap.modify("cn="+self.name+",cn="+grupo+",cn=THINCLIENTS,cn=DHCP Config", attr)
        self.ldap.modify("cn="+self.name+",cn="+grupo+"-wifi,cn=THINCLIENTS,cn=DHCP Config", attr)

        return "OK"

    def modifyIP(self):

        grupo=self.getGroup()
        self.mac=self.getldapMAC(self.name)
        self.macWlan=self.getldapWifiMAC(self.name)        
        if self.mac != "":
            attr = [(ldap.MOD_REPLACE, 'dhcpStatements', ['filename "/var/lib/tftpboot/ltsp/i386/pxelinux.0"', 'fixed-address ' + self.ip])]
            self.ldap.modify("cn="+self.name+",cn="+grupo+",cn=THINCLIENTS,cn=DHCP Config", attr)
        if self.macWlan != "":
            attr = [(ldap.MOD_REPLACE, 'dhcpStatements', ['fixed-address ' + self.ip])]
            self.ldap.modify("cn="+self.name+",cn="+grupo+"-wifi,cn=THINCLIENTS,cn=DHCP Config", attr)      

        return "OK"

    def delete(self):
        group = self.getGroup()
        if group != "noGroup":
            self.ldap.delete('cn='+ self.name +',cn='+group+',cn=THINCLIENTS,cn=DHCP Config')
            self.ldap.delete('cn='+ self.name +',cn='+group+'-wifi,cn=THINCLIENTS,cn=DHCP Config')
            self.deleteEmptyGroup(group) #Si la rama ha quedado vacia, se borra.

        return "OK"

    def move(self,purpose):
        data = self.getHostData()
        self.delete()

        self.name= purpose
        self.mac= data['mac']
        self.macWlan= data['macWlan']
        self.serial= data['serial']
        self.username= data['username']
        self.ip=data['ip']
        self.add()

        return "OK"
               
    def deleteEmptyGroup(self, group): 
        
        #Si el grupo se queda vacio, sin nodos, lo eliminamos.
        
        result = self.ldap.search("cn="+group+",cn=THINCLIENTS,cn=DHCP Config", "(&(cn=*)(objectClass=dhcpHost))",["cn"])                
        if result is not None and len(result) ==0 : self.ldap.delete('cn='+group+',cn=THINCLIENTS,cn=DHCP Config')
        result = self.ldap.search("cn="+group+"-wifi,cn=THINCLIENTS,cn=DHCP Config", "(&(cn=*)(objectClass=dhcpHost))",["cn"])                
        if result is not None and len(result) ==0 : self.ldap.delete('cn='+group+'-wifi,cn=THINCLIENTS,cn=DHCP Config')
                
        return "OK"
        
    def existsHostname(self):
        result = self.ldap.search("cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn"])
        
        if len(result) > 0:
            return True
        
        return False

    def existsWifiNode(self):
        result = self.ldap.search("cn="+self.getGroup()+"-wifi,cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn"])
        if result is not None and len(result) > 0:
            return True
        
        return False

    def existsNode(self):
        result = self.ldap.search("cn="+self.getGroup()+",cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn"])
        if  result is not None and len(result) > 0:
            return True
        
        return False
        
    def existsMAC(self, mac):     
        result = self.ldap.search("cn=THINCLIENTS,cn=DHCP Config","dhcpHWAddress=*",["cn","dhcpHWAddress"])
        for i in range (0, len(result)):
            if result[i][0][1]['dhcpHWAddress'][0].replace ("ethernet", "").strip()==mac and result[i][0][1]['cn'][0]!=self.original_name: #Descartamos comparar la MAC con la propia maquina.
                return True
        
        return False

    def getldapMAC(self, name):
        grupo = self.name.split("-")[0]
        result = self.ldap.search("cn="+grupo+",cn=THINCLIENTS,cn=DHCP Config","cn="+name,["dhcpHWAddress"])
        try:
           mac = result[0][0][1]['dhcpHWAddress'][0].replace("ethernet", "").strip()
        except:
           mac = ""
        return mac

    def getldapWifiMAC(self, name):
        grupo = self.name.split("-")[0]
        result = self.ldap.search("cn="+grupo+"-wifi,cn=THINCLIENTS,cn=DHCP Config","cn="+name,["dhcpHWAddress"])
        try:
           mac = result[0][0][1]['dhcpHWAddress'][0].replace("ethernet", "").strip()
        except:
           mac = ""
        return mac

    def getHostData(self):
        g = self.getGroup()
        
        result = self.ldap.search("cn="+g+",cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn","dhcpHWAddress","dhcpComments","uniqueIdentifier","dhcpStatements"])                
        if result is None or len(result) == 0: #Si no existe en la rama normal, buscamos en la rama "wifi"
            wired=False
            result = self.ldap.search("cn="+g+"-wifi,cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn","dhcpHWAddress","dhcpComments","uniqueIdentifier","dhcpStatements"])
        else:
            wired=True

        serial=""
        username=""
        mac = ""
        macWlan = ""

        try:              
            serial = result[0][0][1]["dhcpComments"][0].replace("serial-number","").strip()
        except:
            serial = ""
            
        try:
            username = result[0][0][1]["uniqueIdentifier"][0].replace("user-name","").strip()
        except:
            username = ""

        if wired: # Si tiene MAC de conexión cableada...
            try:
                mac = result[0][0][1]["dhcpHWAddress"][0].replace("ethernet","").strip()
            except:
                mac = ""

        try:
            result2 = self.ldap.search("cn="+g+"-wifi,cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn","dhcpHWAddress"])
        except:
            pass

        try:
            macWlan = result2[0][0][1]["dhcpHWAddress"][0].replace("ethernet","").strip()
        except:
            macWlan = ""

        try:
            matching = [s for s in result[0][0][1]["dhcpStatements"] if "fixed-address" in s]
            ip=""
            if matching:
                ip=matching[0].replace("fixed-address ","")
        except:
            ip = ""
               
        dataHost = {
            "cn":self.name,
            "mac":mac,
            "macWlan":macWlan,
            "ip":ip,
            "serial":serial,
            "username":username
        }
        return dataHost    
        
    def getUserAssignedHosts(self):
        #Devuelve un diccionario de usuarios con las máquinas que tienen asociadas y sus números de serie.
        
        search = self.ldap.search("cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn","dhcpHWAddress","uniqueIdentifier","dhcpComments","dhcpStatements"])
        rows = {}
        
        for i in search[6:len(search)]:

            if len(i[0][0].split(","))>6 : #Si el cn tiene mas de 7 niveles de profundidad
           
                host = i[0][1]["cn"][0]
                
                try:
                    username = i[0][1]["uniqueIdentifier"][0].replace("user-name","").strip()
                except:
                    username = ""

                try:
                    serial = i[0][1]["dhcpComments"][0].replace("serial-number","").strip()
                except:
                    serial = ""
                                        
                if username != "":  rows[username] = {"host": host, "serial" :serial}
                                                        
        return rows      

    def getGroup (self):
        groups = self.getThinclientGroups()   
        for g in groups['groups']:
            search = self.ldap.search("cn="+g+",cn=THINCLIENTS,cn=DHCP Config","cn="+self.name,["cn"])
            if len(search) == 1:
                return g.replace("-wifi","").strip()  #Quitamos el "-wifi" final del nombre del grupo si lo hubiere.
        return "noGroup"


    def getThinclientGroups (self):
        groups = []
        search = self.ldap.searchOneLevel("cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn"])
        for g in search:
            if g[0][1]["cn"][0]!="192.168.0.0":
                groups.append (g[0][1]["cn"][0])

        return { "groups":groups }


    def groupOverflow(self,group,overflow):
        search = self.ldap.search("cn="+group+",cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn"])       
        if len(search)-2 >= overflow:
            return True
                
        return False
    

    def getFreeGroup (self):
        freeGroup = []
        groups = self.getThinclientGroups()        
        for g in groups['groups']:
            if not self.groupOverflow(g,300):
                return { "freeGroup":g }

        return { "freeGroup" : 'noFreeGroup' }
    
    def newGroup(self,nameGroup):
        attr = [
        ('objectclass', ['top','dhcpGroup','dhcpOptions']),
        ('cn', [nameGroup] ),
        ('dhcpStatements', ['next-server 192.168.0.254','use-host-decl-names on'] ),
        ('dhcpoption', ['log-servers ltspserver'] ),
        ]
                        
        self.ldap.add("cn="+nameGroup+",cn=THINCLIENTS,cn=DHCP Config", attr)
        
        return True

    def getClassroom(self):
        classroom = self.name.split("-")
        return classroom[0]
    
    def getAllComputersNode(self,node):
        computers = []
        search = self.ldap.searchOneLevel("cn="+node+",cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn"])
        if search is not None:
            for g in search:
                computers.append (g[0][1]["cn"][0])
        search = self.ldap.searchOneLevel("cn="+node+"-wifi,cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn"])
        if search is not None:
            for g in search:
                computers.append (g[0][1]["cn"][0])

        computers = list( dict.fromkeys(computers) ) #Remove duplicates
        computers.sort()
        return { "computers":computers }

    def getAllComputers(self):
        
        computers_name = []
        search = self.ldap.search("cn=THINCLIENTS,cn=DHCP Config","(&(cn=*)(objectClass=dhcpHost))",["cn"])
        if search is not None:        
            for g in search:                                
                computers_name.append (g[0][1]["cn"][0])        
        
        computers_name = list( dict.fromkeys(computers_name) ) #Remove duplicates
        computers_name.sort()
           
        computers = []
        for i in computers_name:        
            h = Thinclients(self.ldap,i)
            computer=h.getHostData()
            computers.append (computer)
                
        return { "computers":computers }

    def findFreeGaps(self,node,type,startIN):
        computers = []
        freeGaps = []
        search = self.ldap.searchOneLevel("cn="+node+",cn=THINCLIENTS,cn=DHCP Config","cn=*",["cn"])
        if search:
            for s in search:
                computers.append (s[0][1]["cn"][0])
        
        for r in range(int(startIN),51):
            computer = node+"-"+type+str(r).zfill(2)
            if computer not in computers:
                freeGaps.append (computer)

        return { "computers":computers, "freeGaps":freeGaps }

def log(mensaje):
    logfile = open("/tmp/controlies.txt", "a")
    logfile.write(mensaje+"\n")
    logfile.close()


