# coding: utf8
from applications.controlies.modules.Hosts import Hosts
import logging

def index():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default'))
    return dict()

    
@service.json
def getHostData():
    l=conecta()
    h = Hosts(l,request.vars['cn'],"","","",request.vars['netgroup'])
    response = h.getHostData()    
    l.close()
    return dict(response=response)
    
@service.json   
@auth.requires_login()
def list_ltspservers():
    l=conecta()
    h = Hosts (l,"","","","","")
    response = h.getLTSPServers()
    l.close()
    return response    
   
   
@service.json   
@auth.requires_login()
def list():
    l=conecta()
    h = Hosts (l,"","","","",request.vars['netgroup'])
    a=request.vars
    response = h.list(a)
    l.close()
    return response    

@service.json
@auth.requires_login()
def modify():
    l=conecta()
    h = Hosts(l,request.vars['name'],request.vars['ip'],request.vars['mac'],request.vars['wifimac'],request.vars['netgroup'])
    response=h.process(request.vars['action'],request.vars['name_host']) # en name_host va el nombre original del host editado, para detectar si lo han cambiado
    l.close()
    return dict(response=response)
   
@service.json
@auth.requires_login()    
def delete():
    l=conecta()
    print request.vars
    if(isinstance(request.vars['cn[]'], str)):
        h = Hosts(l,request.vars['cn[]'],"","","","")
        h.process(request.vars['action'],request.vars['cn[]'])
    else:
        for t in request.vars['cn[]']:
            h = Hosts(l,t,"","","","")
            h.process(request.vars['action'],t)

    l.close()
    return dict(response="OK")

@service.json
@auth.requires_login()    
def getallranges():
    from applications.controlies.modules.Utils import LdapUtils
    l=conecta()
    myRanges = LdapUtils.getAllRanges(l)
    return dict(response=myRanges)
    
#necesaria estas funciones en el controlador para poder cargar las vistas correspondientes:    

def equipos():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default',f='index'))

    return dict()


def ltspservers():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default',f='index'))
        
    return dict()

def siatic():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default',f='index'))

    l=conecta()
    search = l.search("ou=Netgroup","cn=siatic-hosts",["cn"])
    if not search:
        h = Hosts(l,"","","","","siatic-hosts")
        h.createStructure()

    return dict()

def workstations():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default',f='index'))
        
    return dict()    

def hardware():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default',f='index'))

    l=conecta()
    search = l.search("ou=Netgroup","cn=hardware-hosts",["cn"])  
    if not search:
        h = Hosts(l,"","","","","hardware-hosts")
        h.createStructure()

    return dict()    

def laptops():
    if not auth.user:
        session.flash='Debe iniciar sesión'
        redirect(URL(c='default',f='index'))

    l=conecta()
    search = l.search("ou=Netgroup","cn=laptop-hosts",["cn"])  
    if not search:
        h = Hosts(l,"","","","","laptop-hosts")
        h.createStructure()

    return dict()    

@service.json
@auth.requires_login()
def getNetGroups():
    l=conecta()
    h = Hosts (l,"","","","","")
    netgroups = h.getNetGroups()
    l.close()
    return dict(response=netgroups)

@service.json
@auth.requires_login()
def getNetGroupsNonEmpty():
    l=conecta()
    h = Hosts (l,"","","","","")
    netgroups = h.getNetGroupsNonEmpty()
    l.close()
    return dict(response=netgroups)

@service.json
@auth.requires_login()   
def moveDevice():
    l=conecta()
    hosts = request.vars.hosts.split(",")
    for h in hosts:
        h1 = Hosts(l,h,"","","",request.vars['source'])
        h2 = Hosts(l,h,"","","",request.vars['netgroup'])
        h1.deleteTriplet()
        h2.addTriplet()

    return dict(response="OK")

def form_ltspserver():
    return dict()

def form_addhost():
    return dict()



def form_move():
    return dict()

def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    session.forget()
    return service()

def log(mensaje):
    logfile = open("/tmp/controlies.txt", "a")
    logfile.write(mensaje+"\n")
    logfile.close()


