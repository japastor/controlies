# coding: utf8
from applications.controlies.modules.NetGroups import NetGroups
                
def index():
    if not auth.user: redirect(URL(c='default'))
    return dict()

@service.json
@auth.requires_login()
def list():
    l=conecta()
    
    g = NetGroups(l,"","")
    a=request.vars
    response = g.list(a)
    l.close()
    return response  
    
@service.json
@auth.requires_login()
def modify():
    l=conecta()
    g = NetGroups(l, request.vars['name'], [])
    response = g.process(request.vars['action'],request.vars['name_netgroup'])  # en name_netgroup va el nombre original del netgroup editado, para detectar si lo han cambiado
    l.close()
    return dict(response=response)

@service.json  
def getNetGroupData():
    l=conecta()
    g = NetGroups(l,request.vars['name'],"")
    response = g.getNetGroupData()
    l.close()
    return dict(response=response)

@service.json  
@auth.requires_login()    
def delete():
    l=conecta()
    g = NetGroups(l,request.vars['name'],[])
    response = g.delete()
    l.close()
    return dict(response=response)

def search():
    return dict()

def form():
    return dict()
    
def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    session.forget()
    return service()
