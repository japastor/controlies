#!/usr/bin/python
##############################################################################
# -*- coding: utf-8 -*-
# Project:     ControlIES
# Module:      avahiClientLTSP.py
# Purpose:     Avahi Client in Classroom network
# Language:    Python 2.5
# Date:        26-Oct-2011.
# Ver:        26-Oct-2011.
# Author:   Manuel Mora Gordillo
# Copyright:    2011 - Manuel Mora Gordillo <manuito @no-spam@ gmail.com>
#
# ControlIES is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# ControlIES is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with ControlIES. If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import sys
import dbus, avahi, os
from gi.repository import GObject as gobject
from dbus import DBusException
from dbus.mainloop.glib import DBusGMainLoop
import xmlrpclib
import ipaddress
import datetime

typeComputers = "_workstation._tcp"
typeStudents = "_controlies._udp"

if len(sys.argv) == 2:
    subred=sys.argv[1]       #Parametro con la IP de la subred donde se filtraran los descubrimientos de avahi
else:
    print("Falta parametro")
    quit(1)

rpcServer = xmlrpclib.ServerProxy("http://localhost:6800", allow_none=True)


def siocgifname(interface):
    if interface <= 0:
            return "n/a"
    else:
            return server.GetNetworkInterfaceNameByIndex(interface)

#####################################################################################################
def newComputer(interface, protocol, name, type, domain, flags):
    try:
        interface, protocol, name, type, domain, host, aprotocol, address, port, txt, flags = server.ResolveService(interface, protocol, name, type, domain, avahi.PROTO_UNSPEC, dbus.UInt32(0))
        iface = siocgifname(interface)

        #Hay que convertirlo a utf8-8, ya que ipaddress solo acepta ese tipo de codificacion. En python3 no hace falta esto.
        if protocol == avahi.PROTO_INET and ipaddress.IPv4Address(address.decode('utf-8', 'ignore')) in ipaddress.IPv4Network(subred.decode('utf-8', 'ignore')):
            rpcServer.append_computer(str(name), str(address))
    except:
        pass

def removeComputer(interface, protocol, name, type, domain, flags):
        rpcServer.remove_computer(str(name))

#####################################################################################################
def newStudent(interface, protocol, name, type, domain, flags):
    try:
        interface, protocol, name, type, domain, host, aprotocol, address, port, txt, flags = server.ResolveService(interface, protocol, name, type, domain, avahi.PROTO_UNSPEC, dbus.UInt32(0))
        iface = siocgifname(interface)
        n = name.split(".")[0].split("@")

        thin = ''.join([chr(byte) for byte in txt[0]]).replace("thinclient=","")   #Esto no se para que vale
        if thin=="True":
             print("Es thinclient")

        #Hay que convertirlo a utf8-8, ya que ipaddress solo acepta ese tipo de codificacion. En python3 no hace falta esto.
        if protocol == avahi.PROTO_INET and ipaddress.IPv4Address(address.decode('utf-8', 'ignore')) in ipaddress.IPv4Network(subred.decode('utf-8', 'ignore')):
            rpcServer.append_student(str(n[0]), str(n[1]), str(address))

    except:
        pass

def removeStudent(interface, protocol, name, type, domain, flags):

    # He intentado que removeStudent compruebe, como hace newStudent, el origen del evento, para filtrar y quedarme con los eventos de la VLAN.
    # Pero no he pidod, las dos lineas siguientes fallan (timeout) en los eventos remove, aunque funcionan en los eventos add. Supongo que será cosas del diseño de avahi
    # interface, protocol, name, type, domain, host, aprotocol, address, port, txt, flags = server.ResolveService(interface, protocol, name, type, domain, avahi.PROTO_UNSPEC, dbus.UInt32(0))
    # iface = siocgifname(interface)

    n = name.split(".")[0].split("@")
    rpcServer.remove_student(str(n[0]),str(n[1]))


def logea(fichero,texto):

   file = open(fichero, 'a')
   ahora=datetime.datetime.today()
   mensaje=ahora.strftime("%d/%m/%Y %H:%M")+":"+texto+ "\n\n"
   file.write(mensaje)
   file.close()


#####################################################################################################
loop = DBusGMainLoop()
bus = dbus.SystemBus(mainloop=loop)
server = dbus.Interface( bus.get_object(avahi.DBUS_NAME, '/'), 'org.freedesktop.Avahi.Server')

sbrowser = dbus.Interface(bus.get_object(avahi.DBUS_NAME, server.ServiceBrowserNew(avahi.IF_UNSPEC, avahi.PROTO_UNSPEC, typeComputers, 'local', dbus.UInt32(0))), avahi.DBUS_INTERFACE_SERVICE_BROWSER)
sbrowser.connect_to_signal("ItemNew", newComputer)
sbrowser.connect_to_signal("ItemRemove", removeComputer)

sbrowser = dbus.Interface(bus.get_object(avahi.DBUS_NAME, server.ServiceBrowserNew(avahi.IF_UNSPEC, avahi.PROTO_UNSPEC, typeStudents, 'local', dbus.UInt32(0))), avahi.DBUS_INTERFACE_SERVICE_BROWSER)
sbrowser.connect_to_signal("ItemNew", newStudent)
sbrowser.connect_to_signal("ItemRemove", removeStudent)

gobject.MainLoop().run()

