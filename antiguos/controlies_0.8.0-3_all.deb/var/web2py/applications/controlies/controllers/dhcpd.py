# coding: utf8
# intente algo como
def index():
#equivalente a list


    return dict(message="hello from dhcpd.py")
    
def delete():
    return dict()
